import {createRoot} from "react-dom/client"
import {CarGarage} from "./CarGarage"
import "./styles.css"
import "./controls.css"
createRoot(document.getElementById("root")!).render(<CarGarage/>)
