import { useEffect, useRef, useState } from "react"
import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js"

type ViewKey="three"|"front"|"rear"|"side"|"top"
type PartKey="frontLeft"|"frontRight"|"rearLeft"|"rearRight"|"hood"|"trunk"
type OpenState=Record<PartKey,boolean>
const closed:OpenState={frontLeft:false,frontRight:false,rearLeft:false,rearRight:false,hood:false,trunk:false}
const labels:Record<PartKey,string>={frontLeft:"Porte avant gauche",frontRight:"Porte avant droite",rearLeft:"Porte arrière gauche",rearRight:"Porte arrière droite",hood:"Capot",trunk:"Coffre"}

function Viewer({view,opened,autoRotate,lights,onReady}:{view:ViewKey;opened:OpenState;autoRotate:boolean;lights:boolean;onReady:()=>void}){
 const host=useRef<HTMLDivElement>(null)
 const runtime=useRef<{camera:THREE.PerspectiveCamera;controls:OrbitControls;parts:Partial<Record<PartKey,THREE.Object3D>>;targets:OpenState;headlights:THREE.PointLight[]}|null>(null)
 useEffect(()=>{
  const el=host.current;if(!el)return
  const scene=new THREE.Scene();scene.background=new THREE.Color(0x07090d);scene.fog=new THREE.FogExp2(0x07090d,.032)
  const camera=new THREE.PerspectiveCamera(35,1,.04,70);camera.position.set(5.4,2.4,5.5)
  const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:"high-performance"});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.domElement.className="car-canvas";el.appendChild(renderer.domElement)
  const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.075;controls.target.set(0,.78,0);controls.minDistance=2.5;controls.maxDistance=9;controls.maxPolarAngle=Math.PI*.54
  scene.add(new THREE.HemisphereLight(0xe8efff,0x101216,1.8))
  const key=new THREE.DirectionalLight(0xffffff,5.4);key.position.set(-4,7,4);key.castShadow=true;scene.add(key)
  const rim=new THREE.DirectionalLight(0x7896ff,3);rim.position.set(5,3,-4);scene.add(rim)
  const warm=new THREE.DirectionalLight(0xffd8bd,1.6);warm.position.set(-5,2,-3);scene.add(warm)
  const floor=new THREE.Mesh(new THREE.CircleGeometry(7.5,96),new THREE.MeshStandardMaterial({color:0x10141c,metalness:.42,roughness:.25}));floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;scene.add(floor)
  const ring=new THREE.Mesh(new THREE.RingGeometry(2.35,2.38,128),new THREE.MeshBasicMaterial({color:0x88a7ff,transparent:true,opacity:.55,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.005;scene.add(ring)
  const headlights=[new THREE.PointLight(0xe8f5ff,0,7,1.6),new THREE.PointLight(0xe8f5ff,0,7,1.6)];headlights[0].position.set(-.76,.63,2.05);headlights[1].position.set(.76,.63,2.05);scene.add(...headlights)
  let disposed=false,raf=0
  new GLTFLoader().load(import.meta.env.BASE_URL+"mg3-detailed.glb",g=>{
   if(disposed)return
   const model=g.scene;model.traverse(o=>{if(o instanceof THREE.Mesh){o.castShadow=true;o.receiveShadow=true}})
   scene.add(model);model.updateMatrixWorld(true)
   let box=new THREE.Box3().setFromObject(model);const size=box.getSize(new THREE.Vector3());const scale=4.25/Math.max(size.x,size.y,size.z);model.scale.setScalar(scale);model.updateMatrixWorld(true)
   box=new THREE.Box3().setFromObject(model);const center=box.getCenter(new THREE.Vector3());model.position.set(-center.x,-box.min.y,-center.z);model.updateMatrixWorld(true)
   if(el.clientWidth<600)camera.position.set(7.1,3.15,7.2)
   const parts:Partial<Record<PartKey,THREE.Object3D>>={};(Object.keys(closed) as PartKey[]).forEach(k=>{const p=model.getObjectByName(k);if(p)parts[k]=p})
   runtime.current={camera,controls,parts,targets:{...closed},headlights};onReady()
  },undefined,()=>el.classList.add("load-error"))
  const resize=()=>{const r=el.getBoundingClientRect();renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix()};const ro=new ResizeObserver(resize);ro.observe(el);resize()
  const animate=()=>{raf=requestAnimationFrame(animate);const r=runtime.current;if(r){const a=.12,angle=(k:PartKey)=>r.targets[k]?1:0
    for(const k of ["frontLeft","rearLeft"] as PartKey[]){const p=r.parts[k];if(p)p.rotation.y=THREE.MathUtils.lerp(p.rotation.y,angle(k)*1.08,a)}
    for(const k of ["frontRight","rearRight"] as PartKey[]){const p=r.parts[k];if(p)p.rotation.y=THREE.MathUtils.lerp(p.rotation.y,angle(k)*-1.08,a)}
    for(const k of ["hood","trunk"] as PartKey[]){const p=r.parts[k];if(p)p.rotation.x=THREE.MathUtils.lerp(p.rotation.x,angle(k)*(k==="hood"?-1.02:1.18),a)}
   }controls.update();renderer.render(scene,camera)};animate()
  return()=>{disposed=true;cancelAnimationFrame(raf);ro.disconnect();controls.dispose();renderer.dispose();renderer.domElement.remove()}
 },[])
 useEffect(()=>{if(runtime.current)runtime.current.targets={...opened}},[opened])
 useEffect(()=>{if(runtime.current)runtime.current.controls.autoRotate=autoRotate},[autoRotate])
 useEffect(()=>{runtime.current?.headlights.forEach(l=>l.intensity=lights?11:0)},[lights])
 useEffect(()=>{const r=runtime.current;if(!r)return;const poses:Record<ViewKey,[[number,number,number],[number,number,number]]>={three:[[5.1,2.4,5.25],[0,.76,0]],front:[[0,1.15,6.7],[0,.72,.2]],rear:[[0,1.2,-6.7],[0,.75,-.1]],side:[[-6.6,1.25,0],[0,.75,0]],top:[[.01,7.3,.01],[0,.2,0]]};const p=poses[view][0],m=(host.current?.clientWidth||1000)<600?1.35:1;r.camera.position.set(p[0]*m,p[1]*m,p[2]*m);r.controls.target.set(...poses[view][1]);r.controls.update()},[view])
 return <div ref={host} className="viewer-shell"><div className="load-state">CHARGEMENT DE LA MG3…</div><div className="viewer-tip">GLISSER · ZOOMER · EXPLORER</div></div>
}

export function CarGarage(){
 const [ready,setReady]=useState(false),[view,setView]=useState<ViewKey>("three"),[opened,setOpened]=useState<OpenState>(closed),[autoRotate,setAutoRotate]=useState(false),[lights,setLights]=useState(true)
 const toggle=(k:PartKey)=>setOpened(s=>({...s,[k]:!s[k]}));const allOpen=Object.values(opened).every(Boolean)
 return <main className="page">
  <header><a className="identity" href="#showroom"><span>MG</span><div><strong>MG3 EXPLORER</strong><small>SHOWROOM INTERACTIF</small></div></a><div className="header-meta"><span>HYBRID+</span><span>DOVER WHITE</span><i className={ready?"ready":""}/></div></header>
  <section className="hero" id="showroom">
   <div className="intro"><p>MG3 HYBRID+ LUXURY</p><h1>Explorez-la<br/><em>sous tous les angles.</em></h1><span>Ouvrez les portes, découvrez le moteur et inspectez le coffre depuis votre navigateur.</span></div>
   <Viewer view={view} opened={opened} autoRotate={autoRotate} lights={lights} onReady={()=>setReady(true)}/>
   <aside className="control-panel">
    <div className="panel-head"><div><p>OUVRANTS</p><strong>Explorez votre MG3</strong></div><button className="all" onClick={()=>setOpened(allOpen?closed:{frontLeft:true,frontRight:true,rearLeft:true,rearRight:true,hood:true,trunk:true})}>{allOpen?"Tout fermer":"Tout ouvrir"}</button></div>
    <div className="parts">{(Object.keys(labels) as PartKey[]).map((k,i)=><button key={k} className={opened[k]?"open":""} onClick={()=>toggle(k)}><span>{String(i+1).padStart(2,"0")}</span><strong>{labels[k]}</strong><i>{opened[k]?"FERMER":"OUVRIR"}</i></button>)}</div>
    <div className="extras"><button className={lights?"on":""} onClick={()=>setLights(v=>!v)}><i/>Phares</button><button className={autoRotate?"on":""} onClick={()=>setAutoRotate(v=>!v)}><i/>360°</button></div>
   </aside>
   <nav className="views" aria-label="Choisir une vue">{(["three","front","rear","side","top"] as ViewKey[]).map(v=><button key={v} className={view===v?"active":""} onClick={()=>setView(v)}>{v==="three"?"3/4":v==="front"?"Avant":v==="rear"?"Arrière":v==="side"?"Profil":"Dessus"}</button>)}</nav>
  </section>
  <section className="details"><p>UN MODÈLE À EXPLORER</p><h2>Une MG3 blanche,<br/>dans les moindres détails.</h2><div className="specs"><div><strong>6</strong><span>ouvrants interactifs</span></div><div><strong>5</strong><span>angles de caméra</span></div><div><strong>3D</strong><span>temps réel</span></div></div><small>Modèle Web optimisé à partir de la géométrie MG3 fournie. Compartiment moteur et garnitures intérieures reconstitués pour l'expérience interactive.</small></section>
  <footer><strong>MG3 EXPLORER</strong><span>Expérience 3D personnelle · Hébergée sur GitHub Pages</span></footer>
 </main>
}
