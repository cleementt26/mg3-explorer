import {createRoot} from "react-dom/client"
import {CarGarage} from "./CarGarage"
import "./styles.css"
createRoot(document.getElementById("root")!).render(<CarGarage/>)
