"use client"

import { useEffect, useRef, useState } from "react"
import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js"

type LoadState="loading"|"loaded"|"error"

type ViewKey="three"|"front"|"rear"|"side"|"top"

function Viewer({view,autoRotate,studio,onStatus}:{view:ViewKey;autoRotate:boolean;studio:boolean;onStatus:(state:LoadState)=>void}){
 const [loadState,setLoadState]=useState<LoadState>("loading")
 const host=useRef<HTMLDivElement>(null)
 const rt=useRef<{controls:OrbitControls;camera:THREE.PerspectiveCamera;renderer:THREE.WebGLRenderer}|null>(null)
 const studioRef=useRef(studio);studioRef.current=studio
 useEffect(()=>{
  const el=host.current;if(!el)return
  const scene=new THREE.Scene();scene.background=new THREE.Color(0x05070c);scene.fog=new THREE.FogExp2(0x05070c,.026)
  const camera=new THREE.PerspectiveCamera(40,1,.05,80);camera.position.set(-5.2,2.3,-4.8)
  let renderer:THREE.WebGLRenderer
  try {renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:"high-performance"})} catch {setLoadState("error");onStatus("error");return}
  let disposed=false
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.65));renderer.outputColorSpace=THREE.SRGBColorSpace
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap
  renderer.domElement.className="car-canvas";el.appendChild(renderer.domElement)
  const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.075
  controls.target.set(0,.75,0);controls.minDistance=2.3;controls.maxDistance=9;controls.maxPolarAngle=Math.PI*.53;controls.autoRotateSpeed=.75

  scene.add(new THREE.HemisphereLight(0xd9e4ff,0x10131a,1.6))
  const key=new THREE.DirectionalLight(0xffffff,4.8);key.position.set(-4,7,-4);key.castShadow=true;scene.add(key)
  const rim=new THREE.DirectionalLight(0x7798ff,3.0);rim.position.set(4,4,4);scene.add(rim)
  const warm=new THREE.DirectionalLight(0xffd7bc,1.35);warm.position.set(-4,3,4);scene.add(warm)

  const floor=new THREE.Mesh(new THREE.CircleGeometry(7.5,96),new THREE.MeshStandardMaterial({color:0x090d15,metalness:.38,roughness:.22}))
  floor.rotation.x=-Math.PI/2;floor.position.y=-.012;floor.receiveShadow=true;scene.add(floor)
  const ring=new THREE.Mesh(new THREE.RingGeometry(2.58,2.61,128),new THREE.MeshBasicMaterial({color:0x4969ba,transparent:true,opacity:.58,side:THREE.DoubleSide}))
  ring.rotation.x=-Math.PI/2;ring.position.y=-.006;scene.add(ring)

  const white=new THREE.MeshPhysicalMaterial({color:0xf0f2f5,metalness:.08,roughness:.25,clearcoat:.65,clearcoatRoughness:.12})
  const wheel=new THREE.MeshStandardMaterial({color:0x252a32,metalness:.48,roughness:.34})
  const loader=new GLTFLoader()
  loader.load(import.meta.env.BASE_URL+"car-user-stl.glb",gltf=>{
    if(disposed)return
    const model=gltf.scene
    // Source STL uses Z up; Three.js uses Y up. Keep vertex data unchanged.
    model.rotation.x=-Math.PI/2
    model.traverse(o=>{
      if(o instanceof THREE.Mesh){
        if(!o.geometry.getAttribute("normal"))o.geometry.computeVertexNormals()
        o.castShadow=true;o.receiveShadow=true
        const n=(o.name+" "+o.parent?.name).toLowerCase()
        o.material=n.includes("body")?white:wheel
      }
    })
    scene.add(model)
    model.updateMatrixWorld(true)
    let box=new THREE.Box3().setFromObject(model)
    const size=box.getSize(new THREE.Vector3())
    const longest=Math.max(size.x,size.y,size.z)
    const s=4.113/longest
    model.scale.setScalar(s);model.updateMatrixWorld(true)
    box=new THREE.Box3().setFromObject(model)
    const center=box.getCenter(new THREE.Vector3())
    model.position.x-=center.x;model.position.z-=center.z;model.position.y-=box.min.y
    model.updateMatrixWorld(true)
    const finalBox=new THREE.Box3().setFromObject(model)
    const finalCenter=finalBox.getCenter(new THREE.Vector3())
    controls.target.set(finalCenter.x,Math.max(.65,finalCenter.y),finalCenter.z)
    controls.update()
    setLoadState("loaded");onStatus("loaded")
  },undefined,()=>{if(!disposed){setLoadState("error");onStatus("error")}})

  const resize=()=>{const r=el.getBoundingClientRect();renderer.setSize(r.width,r.height,false);camera.aspect=Math.max(r.width,1)/Math.max(r.height,1);camera.updateProjectionMatrix()}
  const ro=new ResizeObserver(resize);ro.observe(el);resize();rt.current={controls,camera,renderer}
  let raf=0
  const loop=()=>{raf=requestAnimationFrame(loop);controls.update();renderer.toneMappingExposure=THREE.MathUtils.lerp(renderer.toneMappingExposure,studioRef.current?1.5:1.08,.05);renderer.render(scene,camera)}
  loop()
  return()=>{disposed=true;rt.current=null;scene.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();const materials=Array.isArray(o.material)?o.material:[o.material];materials.forEach(m=>m.dispose())}});cancelAnimationFrame(raf);ro.disconnect();controls.dispose();white.dispose();wheel.dispose();renderer.dispose();renderer.domElement.remove()}
 },[])

 useEffect(()=>{const r=rt.current;if(!r)return;const poses:Record<ViewKey,{p:[number,number,number];t:[number,number,number]}>={
  three:{p:[5.2,2.25,-4.8],t:[0,.73,0]},front:{p:[6.3,1.35,0],t:[.4,.72,0]},
  rear:{p:[-6.2,1.35,0],t:[-.4,.72,0]},side:{p:[0,1.35,-6.4],t:[0,.72,0]},top:{p:[.01,7,.01],t:[0,.3,0]}}
  const x=poses[view];r.camera.position.set(...x.p);r.controls.target.set(...x.t);r.controls.update()},[view])
 useEffect(()=>{if(rt.current)rt.current.controls.autoRotate=autoRotate},[autoRotate])
 return <div ref={host} className="viewer-shell" role="region" aria-label="Showroom 3D MG3">{loadState!=="loaded"&&<div className="viewer-message" role={loadState==="error"?"alert":"status"}>{loadState==="error"?"Le modèle 3D ne peut pas être affiché. Vérifiez votre connexion et la prise en charge de WebGL, puis rechargez la page.":"Chargement du modèle 3D…"}</div>}<div className="model-badge">STL UTILISATEUR · MODÈLE DE RÉFÉRENCE</div><div className="viewer-help">GLISSER POUR TOURNER · PINCER / MOLETTE POUR ZOOMER</div></div>
}

export function CarGarage(){
 const [status,setStatus]=useState<LoadState>("loading")
 const [view,setView]=useState<ViewKey>("three")
 const [autoRotate,setAutoRotate]=useState(false)
 const [studio,setStudio]=useState(false)
 return <main className="garage-page">
  <header className="garage-header"><div className="brand-lockup"><span className="mg-chip">3D</span><div><strong>MG3 NIGHT GARAGE</strong><small>HATCHBACK PERSONNEL · MODÈLE UTILISATEUR</small></div></div><div className="spec-pills"><span>STL SOURCE UTILISATEUR</span><span>4 ROUES SÉPARÉES</span><span>WEB OPTIMISÉ</span></div></header>
  <section className="showroom">
   <div className="hero-copy"><span className="eyebrow">TON VRAI MODÈLE 3D · V3</span><h1>Ta voiture.<br/><em>Cette fois, la bonne.</em></h1><p>Le modèle affiché est directement dérivé de la carrosserie et des quatre roues STL que tu as fournies.</p></div>
   <Viewer view={view} autoRotate={autoRotate} studio={studio} onStatus={setStatus}/>
   <div className="view-dock">{(["three","front","rear","side","top"] as ViewKey[]).map(v=><button key={v} aria-pressed={view===v} className={view===v?"active":""} onClick={()=>setView(v)}>{v==="three"?"3/4":v==="front"?"Face":v==="rear"?"Arrière":v==="side"?"Profil":"Dessus"}</button>)}</div>
  </section>
  <section className="control-zone">
   <div className="control-intro"><div><span className="eyebrow">MODÈLE DE RÉFÉRENCE</span><h2>La géométrie vient de tes fichiers.</h2></div><div className="status" role="status"><i className={status==="loaded"?"live":""}/>{status==="loaded"?"Modèle STL chargé":status==="error"?"Modèle indisponible":"Chargement du modèle…"}</div></div>
   <div className="quick-actions"><button aria-pressed={studio} aria-label="Ambiance Studio" className={studio?"on":""} onClick={()=>setStudio(v=>!v)}>{studio?"Studio":"Nocturne"}</button><button aria-pressed={autoRotate} className={autoRotate?"on":""} onClick={()=>setAutoRotate(v=>!v)}>Rotation 360°</button></div>
   <div className="engineering-card"><div><span>CARROSSERIE STL</span><strong>180,531 mm</strong></div><div><span>LARGEUR STL</span><strong>88,526 mm</strong></div><div><span>HAUTEUR STL</span><strong>56,751 mm</strong></div><div><span>ROUES</span><strong>4 maillages</strong></div><div><span>SOURCE</span><strong>Fichiers STL fournis</strong></div><div><span>MODE WEB</span><strong>Maillage allégé</strong></div></div>
   <div className="stl-note"><strong>Pourquoi les ouvrants ont disparu ?</strong><span>La carrosserie STL fournie est un seul maillage statique et ne contient pas d'intérieur exploitable. J'ai donc supprimé les faux ouvrants buggés. La prochaine étape propre consiste à découper ce maillage pour créer de vraies portes, un capot et un hayon.</span></div>
   <p className="model-note">L'optimisation Web réduit le nombre de triangles sans redessiner la silhouette. Le modèle d'origine reste inchangé dans tes fichiers source.</p>
  </section>
 </main>
}
